package com.example.immatriculationservice.repositories;

import com.example.immatriculationservice.entities.Proprietaire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource
public interface proprietaireRepository extends JpaRepository<Proprietaire,Long> {

}
