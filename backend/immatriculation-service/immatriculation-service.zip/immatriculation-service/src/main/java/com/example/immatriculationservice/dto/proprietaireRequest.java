package com.example.immatriculationservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@ Data
@NoArgsConstructor @AllArgsConstructor
public class proprietaireRequest{
    private String name;
    private String email;
}
