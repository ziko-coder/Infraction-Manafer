package com.example.immatriculationservice.web.restController;

import com.example.immatriculationservice.entities.Vehicule;
import com.example.immatriculationservice.repositories.vehiculeRepository;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

//@RestController
@AllArgsConstructor
public class vehiculeRestController {
    private vehiculeRepository vehiculeRepo;

    @GetMapping("/vehicules")
    public List<Vehicule> getAllVehicules() {
        return vehiculeRepo.findAll();
    }

    @GetMapping("vehicules/{id}")
    public Vehicule getVehiculeById(@PathVariable Long id) {
        return vehiculeRepo.findById(id).orElse(null);
    }

    @PostMapping("/vehicules")
    public Vehicule saveVehicule(@RequestBody Vehicule vehicule) {
        return vehiculeRepo.save(vehicule);
    }

    @PutMapping("/{id}")
    public Vehicule updateVehicule(@RequestBody Vehicule vehicule, @PathVariable Long id) {
        vehicule.setId(id);
        return vehiculeRepo.save(vehicule);
    }

    @DeleteMapping("/{id}")
    public void deleteVehicule(@PathVariable Long id) {
        vehiculeRepo.deleteById(id);
    }
}
