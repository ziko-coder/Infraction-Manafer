package com.example.immatriculationservice;

import com.example.immatriculationservice.entities.Proprietaire;
import com.example.immatriculationservice.entities.Vehicule;
import com.example.immatriculationservice.repositories.proprietaireRepository;
import com.example.immatriculationservice.repositories.vehiculeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import java.time.LocalDate;

@SpringBootApplication

public class ImmatriculationServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(ImmatriculationServiceApplication.class, args);
    }

    @Bean
    public CommandLineRunner init(proprietaireRepository proprietaireRepository, vehiculeRepository vehiculeRepository) {
        return args -> {
            Proprietaire proprietaire1 = new Proprietaire(); // Create an instance using the default constructor
            proprietaire1.setName("Oumaima");
            proprietaire1.setBirthDate(LocalDate.of(2000, 2, 7));
            proprietaire1.setEmail("aitbahao.etu@gmail.com");

            Proprietaire proprietaire2 = new Proprietaire();
            proprietaire2.setName("Anas");
            proprietaire2.setBirthDate(LocalDate.of(1995, 9, 16));
            proprietaire2.setEmail("anas@gmail.com");

            Proprietaire proprietaire3 = new Proprietaire();
            proprietaire3.setName("Saad");
            proprietaire3.setBirthDate(LocalDate.of(2004, 11, 1));
            proprietaire3.setEmail("saad@gmail.com");
            //saving
            proprietaireRepository.save(proprietaire1);
            proprietaireRepository.save(proprietaire2);
            proprietaireRepository.save(proprietaire3);
            //
            Vehicule vehicle1 = new Vehicule(); // Create an instance using the default constructor
            vehicle1.setRegistrationNumber("ABC123");
            vehicle1.setBrand("Toyota");
            vehicle1.setModel("chihaja");
            vehicle1.setFiscalPower(6);

            Vehicule vehicle2 = new Vehicule();
            vehicle2.setRegistrationNumber("12AABB");
            vehicle2.setBrand("skoda");
            vehicle2.setModel("man3rf");
            vehicle2.setFiscalPower(7);

            Vehicule vehicle3 = new Vehicule();
            vehicle3.setRegistrationNumber("z20DD");
            vehicle3.setBrand("lamborghini");
            vehicle3.setModel("typeinconnu");
            vehicle3.setFiscalPower(12);

            vehiculeRepository.save(vehicle1);
            vehiculeRepository.save(vehicle2);
            vehiculeRepository.save(vehicle3);

            System.out.println("All Owners:");
            proprietaireRepository.findAll().forEach(owner -> {
                System.out.println(owner.toString());
            });

            System.out.println("All Vehicles:");
            vehiculeRepository.findAll().forEach(vehicle -> {
                System.out.println(vehicle.toString());
            });
        };

    }
}
