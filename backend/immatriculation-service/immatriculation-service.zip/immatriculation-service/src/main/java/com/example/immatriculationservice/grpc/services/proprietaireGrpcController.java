package com.example.immatriculationservice.grpc.services;



public class proprietaireGrpcController {
}
