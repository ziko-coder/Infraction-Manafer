package com.example.immatriculationservice.web.restController;

import com.example.immatriculationservice.entities.Proprietaire;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import  com.example.immatriculationservice.repositories.proprietaireRepository;

import java.util.List;

//@RestController
@AllArgsConstructor //generer constructeur avec parametres
public class proprietaireRestController {
    private  proprietaireRepository proprietaireRepo;

    @GetMapping("/proprietaires")
    public List<Proprietaire> getAllProprietaires() {
        return proprietaireRepo.findAll();
    }

    @GetMapping("proprietaires/{id}")
    public Proprietaire getProprietaireById(@PathVariable Long id) {
        return proprietaireRepo.findById(id).orElse(null);
    }

    @PostMapping("/proprietaires")
    public Proprietaire saveProprietaire(@RequestBody Proprietaire proprietaire) {
        proprietaireRepo.save(proprietaire);
        return proprietaire;
    }

    @PutMapping("/{id}")
    public Proprietaire updateProprietaire(@RequestBody Proprietaire proprietaire, @PathVariable Long id) {
        proprietaire.setId(id);
        return proprietaireRepo.save(proprietaire);
    }

    @DeleteMapping("/{id}")
    public void deleteProprietaire(@PathVariable Long id) {
        proprietaireRepo.deleteById(id);
    }
}
