package com.example.immatriculationservice.web.soapController;


import com.example.immatriculationservice.dto.proprietaireRequest;
import com.example.immatriculationservice.entities.Proprietaire;
import com.example.immatriculationservice.mapper.proprietaireMapper;
import com.example.immatriculationservice.repositories.proprietaireRepository;
import jakarta.jws.WebMethod;
import jakarta.jws.WebParam;
import jakarta.jws.WebService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@AllArgsConstructor
//@WebService(serviceName = "proprietaireWS")
public class proprietaireSoap {
    private proprietaireRepository  proprietaireRepository;
    private proprietaireMapper mapper;
    @WebMethod
    public List<Proprietaire> proprietaireList(){
        return proprietaireRepository.findAll();
    }
    //return owner
    @WebMethod
    public Proprietaire proprietaireById(@WebParam(name = "id") Long id){
        return proprietaireRepository.findById(id).orElse(null);
    }
    //savemethod
    @WebMethod
    public  Proprietaire saveProprietaire(@WebParam proprietaireRequest request){
        Proprietaire proprietaire=mapper.from(request);
        return  proprietaireRepository.save(proprietaire);
    }

}
